#!/usr/bin/env python3
"""
qa_check.py — Hallym Investment 발표자료 자동 품질 점검 v2

사용법:
    python3 qa_check.py deck.pptx [--report report.docx|report.pdf|report.txt]

점검 항목 (문제 = 반드시 고칠 것, 확인 필요 = 사람이 판단할 것):
  1. 쪽수: 13~17장(15장 내외)                                       [문제]
  2. 발표자 노트: 모든 슬라이드에 있고 200자 이상(약 1분)             [문제]
  3. 출처: 본문 레이아웃(H_CONTENT, H_DARK) 출처 영역이 비어 있지 않음 [문제]
  4. 경계: 도형·텍스트가 슬라이드 밖으로 나가지 않음                  [문제]
  5. 글자 크기: 9pt 미만 텍스트가 없음                                [문제]
  6. 텍스트 넘침(추정): 글자 수와 상자 크기로 넘칠 가능성 추정         [확인 필요]
  7. 텍스트 겹침: 서로 다른 텍스트 상자가 겹침                         [확인 필요]
  8. 수치 대조(--report): 보고서에 없는 숫자가 있는데 'Hallym 추정'이나
     '(E)' 표기가 없는 슬라이드                                        [확인 필요]
  9. 네이티브 차트 수, 그림 개체 수                                     [정보]

종료 코드: 0 = 통과, 1 = 확인 필요만 있음, 2 = 문제 있음
노트 기준 200자는 SKILL.md와 hallym_deck.js(NOTES_MIN)와 같다.
"""
import math
import re
import subprocess
import sys
import zipfile
from pptx import Presentation

EMU = 914400
NOTES_MIN = 200
CONTENT_LAYOUTS = {"H_CONTENT", "H_DARK"}
DATE_PAT = re.compile(r"^(19|20)\d\d(\.\d{1,2}){0,2}$|^\d{1,2}\.\d{1,2}$")  # 2018, 2018.5, 2026.10.21, 10.28


def numbers_in(text):
    out = set()
    for r in re.findall(r"\d[\d,]*(?:\.\d+)?", text):
        n = r.replace(",", "")
        if len(n.replace(".", "")) < 2 or DATE_PAT.match(n):
            continue
        out.add(n)
        if "." in n:  # 107.4 와 107.40 같은 표기 차이 흡수
            out.add(n.rstrip("0").rstrip("."))
    return out


def report_numbers(path):
    p = path.lower()
    if p.endswith(".docx"):
        with zipfile.ZipFile(path) as z:
            xml = z.read("word/document.xml").decode("utf-8")
        # 문단·표 셀 경계를 줄바꿈으로 바꿔 이웃 칸 숫자가 붙지 않게 한다
        xml = re.sub(r"</w:p>|</w:tc>|<w:tab/>|<w:br/>", "\n", xml)
        text = re.sub(r"<[^>]+>", "", xml)
    elif p.endswith(".pdf"):
        text = subprocess.run(["pdftotext", "-layout", path, "-"], capture_output=True, text=True).stdout
    else:
        text = open(path, encoding="utf-8", errors="ignore").read()
    return numbers_in(text)


def est_lines(text, width_in, pt):
    per_line = max(1.0, width_in * 72 / pt)
    total = 0
    for line in text.split("\n"):
        em = sum(1.0 if "ㄱ" <= ch <= "힝" else 0.55 for ch in line)
        total += max(1, math.ceil(em / per_line))
    return total


def run_size(shape):
    sizes = [r.font.size.pt for p in shape.text_frame.paragraphs for r in p.runs if r.font.size]
    return max(sizes) if sizes else 14.0


def overlap(a, b):
    ax0, ay0, ax1, ay1 = a.left, a.top, a.left + a.width, a.top + a.height
    bx0, by0, bx1, by1 = b.left, b.top, b.left + b.width, b.top + b.height
    w, h = min(ax1, bx1) - max(ax0, bx0), min(ay1, by1) - max(ay0, by0)
    if w <= 0 or h <= 0:
        return 0
    return (w * h) / max(1, min(a.width * a.height, b.width * b.height))


def main():
    if len(sys.argv) < 2:
        print(__doc__)
        sys.exit(1)
    deck = sys.argv[1]
    report = sys.argv[sys.argv.index("--report") + 1] if "--report" in sys.argv else None
    prs = Presentation(deck)
    sw, sh = prs.slide_width, prs.slide_height
    problems, checks, info = [], [], []
    n = len(prs.slides)
    info.append(f"슬라이드 수: {n}장")
    if not 13 <= n <= 17:
        problems.append(f"[쪽수] {n}장 — 권장 15장 내외(13~17장)")
    rep = report_numbers(report) if report else None
    charts = pics = 0

    for i, slide in enumerate(prs.slides, 1):
        layout = slide.slide_layout.name
        notes = slide.notes_slide.notes_text_frame.text.strip() if slide.has_notes_slide else ""
        if not notes:
            problems.append(f"[노트] {i}번 슬라이드에 발표자 노트가 없음")
        elif len(notes) < NOTES_MIN:
            problems.append(f"[노트] {i}번 슬라이드 노트 {len(notes)}자 — 1분 분량({NOTES_MIN}자 이상) 필요")
        src = ""
        if layout in CONTENT_LAYOUTS:
            for ph in slide.placeholders:
                if "BODY" in str(ph.placeholder_format.type):
                    src += ph.text_frame.text
            if not src.strip():
                problems.append(f"[출처] {i}번 슬라이드 출처 영역이 비어 있음")
        texts, slide_text = [], []
        for shp in slide.shapes:
            if shp.left is not None and shp.width is not None and shp.name != "cover-image":
                if shp.left < 0 or shp.top < 0 or shp.left + shp.width > sw + 1 or shp.top + shp.height > sh + 1:
                    problems.append(f"[경계] {i}번 슬라이드 '{shp.name}'가 슬라이드 밖으로 나감")
            if shp.has_chart:
                charts += 1
            if shp.shape_type == 13:
                pics += 1
            if shp.has_table:
                for row in shp.table.rows:
                    for cell in row.cells:
                        slide_text.append(cell.text)
            if shp.has_text_frame and shp.text_frame.text.strip():
                t = shp.text_frame.text
                slide_text.append(t)
                for p in shp.text_frame.paragraphs:
                    for r in p.runs:
                        if r.font.size is not None and r.font.size.pt < 9 and r.text.strip():
                            problems.append(f"[글자] {i}번 슬라이드 '{r.text[:15]}' {r.font.size.pt}pt — 9pt 이상")
                if shp.width and shp.height:
                    pt = run_size(shp)
                    need = est_lines(t, shp.width / EMU, pt) * pt * 1.25 / 72
                    if need > shp.height / EMU * 1.15 + 0.05:
                        checks.append(f"[넘침?] {i}번 슬라이드 '{t[:18]}…' 추정 {need:.2f}in > 상자 {shp.height / EMU:.2f}in")
                    texts.append(shp)
        for a_i in range(len(texts)):
            for b_i in range(a_i + 1, len(texts)):
                if overlap(texts[a_i], texts[b_i]) > 0.15:
                    checks.append(f"[겹침?] {i}번 슬라이드 '{texts[a_i].text_frame.text[:12]}'와 '{texts[b_i].text_frame.text[:12]}'")
        if rep is not None:
            allt = "\n".join(slide_text)
            missing = sorted(x for x in numbers_in(allt) if x not in rep)
            marked = re.search(r"Hallym 추정|추정|\(E\)|계산", allt + src)
            if missing and not marked:
                checks.append(f"[수치] {i}번 슬라이드: 보고서에서 찾지 못한 숫자 {missing} — 오타인지, 계산값이면 출처에 'Hallym 추정' 표기")
            elif missing:
                info.append(f"[수치 참고] {i}번 슬라이드: 보고서 외 숫자 {missing} (추정 표기 있음)")

    info.append(f"네이티브 차트: {charts}개, 그림 개체: {pics}개")
    print("== Hallym 발표자료 QA v2 ==")
    for x in info:
        print("·", x)
    if checks:
        print(f"\n확인 필요 {len(checks)}건 (렌더링 이미지로 직접 확인):")
        for c in checks:
            print("  -", c)
    if problems:
        print(f"\n문제 {len(problems)}건:")
        for p in problems:
            print("  -", p)
        sys.exit(2)
    print("\n자동 점검 통과." + (" 확인 필요 항목을 시각 점검으로 확인하세요." if checks else " 시각 점검을 이어서 진행하세요."))
    sys.exit(1 if checks else 0)


if __name__ == "__main__":
    main()
