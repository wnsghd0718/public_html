/**
 * hallym_deck.js — Hallym Investment 브랜드 발표자료 라이브러리 v2 (pptxgenjs 기반)
 *
 * 사용법:
 *   const H = require("<이 skill 폴더>/scripts/hallym_deck.js");
 *   (async () => {
 *     const deck = H.createDeck({ title: "보고서 제목", shortTitle: "머리글용 짧은 제목", author: "작성자" });
 *     await H.loadIcons(deck, ["FaMicrochip", "FaFileContract"]);   // 아이콘을 쓸 경우 먼저 불러온다
 *     H.cover(deck, {...}, "발표자 노트");
 *     H.kpi(deck, {...}, "발표자 노트");
 *     await H.finalize(deck, "output.pptx");
 *   })();
 *
 * 모든 슬라이드 함수는 (deck, spec, notes) 형태다.
 * - notes(발표 대본)는 1분 분량(200~350자)을 기준으로 하며, 200자 미만이면 경고한다.
 * - 본문 슬라이드는 spec.source(출처)가 없으면 경고한다.
 * - 항목이 4개를 넘으면 경고한다 (한 슬라이드 3~4개 원칙).
 */
const fs = require("fs");
const path = require("path");
const pptxgen = require("pptxgenjs");

// ---------------------------------------------------------------- 브랜드 토큰
const BRAND = {
  navy: "0B1F3A",   // 기본: 제목, 어두운 배경
  navy2: "13305A",  // 어두운 배경 위 카드
  teal: "0E7C86",   // 강조: 브랜드 표기, 핵심 문구
  gold: "C9A227",   // 핵심 수치
  ss: "2E5BBA",     // 삼성전자
  sk: "E07A1F",     // SK하이닉스
  other: "9CA3AF",  // 그 밖의 비교 기업(예: 마이크론)
  grey: "6B7280",   // 보조 텍스트, 출처
  ink: "1F2937",    // 본문
  tint: "EEF2F7",   // 카드 배경
  tealTint: "E6F3F4",
  red: "B42318", redTint: "FDECEC",
  amber: "B7791F", amberTint: "FFF4E0",
  green: "1E7B4F", greenTint: "E7F5EE",
  white: "FFFFFF",
  line: "D9DEE5",
  mute: "9CA3AF",   // 어두운 배경 위 보조 텍스트
  soft: "C9D3E0",   // 어두운 배경 위 본문
};
const FONT = "Malgun Gothic"; // 맑은 고딕
const SIZE = { title: 22, sectionTitle: 34, coverTitle: 38, body: 14, small: 12, caption: 10, kpi: 40, brand: 9 };
const W = 10, H = 5.625, M = 0.5;          // 16:9 캔버스, 기본 여백
const CONTENT_TOP = 1.35, CONTENT_BOTTOM = 5.0;
const NOTES_MIN = 200, MAX_ITEMS = 4;

const THEME = {
  name: "Hallym Investment",
  headFontFace: FONT,
  bodyFontFace: FONT,
  colors: {
    dk1: BRAND.navy, lt1: BRAND.white, dk2: BRAND.ink, lt2: BRAND.tint,
    accent1: BRAND.teal, accent2: BRAND.gold, accent3: BRAND.ss, accent4: BRAND.sk,
    accent5: BRAND.grey, accent6: BRAND.red, hlink: BRAND.teal, folHlink: BRAND.grey,
  },
};

const STATUS = {
  "경고": { fg: BRAND.red, bg: BRAND.redTint },
  "주의": { fg: BRAND.amber, bg: BRAND.amberTint },
  "안전": { fg: BRAND.green, bg: BRAND.greenTint },
};

// ---------------------------------------------------------------- 공통 유틸
const txt = (extra = {}) => Object.assign({ fontFace: FONT, isTextBox: true, margin: 0, color: BRAND.ink, valign: "top" }, extra);
const warn = (m) => console.warn("[hallym-deck] " + m);

function requireNotes(slide, notes, label) {
  const n = (notes || "").trim().length;
  if (n < NOTES_MIN) warn(`'${label}' 슬라이드 발표자 노트가 ${n}자입니다. 1분 분량(${NOTES_MIN}~350자)으로 쓰세요.`);
  if (notes) slide.addNotes(notes);
}
function requireSource(spec, label) {
  if (!spec.source) warn(`'${label}' 슬라이드에 출처(source)가 없습니다. 수치가 없다면 source: "자료: Hallym Investment"로 명시하세요.`);
}
function checkItems(arr, label, what) {
  if (arr && arr.length > MAX_ITEMS) warn(`'${label}'의 ${what}이(가) ${arr.length}개입니다. 한 슬라이드 3~4개 원칙에 맞게 줄이거나 나누세요.`);
}
function estimateLines(text, widthIn, pt) {
  // 한글은 글자당 약 1em, 영문·숫자는 약 0.55em으로 추정
  const perLine = Math.max(1, (widthIn * 72) / pt);
  return String(text).split("\n").reduce((a, line) => {
    let em = 0;
    for (const ch of line) em += /[ㄱ-힝]/.test(ch) ? 1 : 0.55;
    return a + Math.max(1, Math.ceil(em / perLine));
  }, 0);
}

/** 큰 문구가 한 줄에 들어가도록 글자 크기를 계산한다 */
function fitSize(text, widthIn, maxPt, minPt = 28) {
  let em = 0;
  for (const ch of String(text).split("\n")[0]) em += /[\u3131-\uD79D]/.test(ch) ? 1 : 0.6;
  return Math.max(minPt, Math.min(maxPt, Math.floor((widthIn * 72 * 0.95) / Math.max(1, em))));
}

// ---------------------------------------------------------------- 아이콘
/** react-icons 아이콘을 PNG로 미리 렌더링해 deck에 저장한다. 슬라이드 함수에서는 이름으로 쓴다. */
async function loadIcons(deck, names, color = "FFFFFF") {
  let React, ReactDOMServer, sharp, libs;
  try {
    React = require("react"); ReactDOMServer = require("react-dom/server"); sharp = require("sharp");
    libs = { Fa: require("react-icons/fa"), Md: require("react-icons/md") };
  } catch (e) {
    warn("아이콘 라이브러리(react, react-dom, react-icons, sharp)를 불러오지 못해 아이콘 없이 진행합니다: " + e.message);
    return;
  }
  for (const name of names) {
    const lib = libs[name.slice(0, 2)];
    if (!lib || !lib[name]) { warn(`아이콘 '${name}'을(를) 찾지 못했습니다.`); continue; }
    const svg = ReactDOMServer.renderToStaticMarkup(React.createElement(lib[name], { color: "#" + color, size: "256" }));
    const buf = await sharp(Buffer.from(svg)).png().toBuffer();
    deck.icons[name] = "image/png;base64," + buf.toString("base64");
  }
}
/** 색 원 안에 아이콘을 넣는다. 아이콘이 없으면 번호나 글자를 넣는다. */
function iconCircle(deck, s, { x, y, d, fill, icon, label, name }) {
  s.addShape("ellipse", { x, y, w: d, h: d, fill: { color: fill }, line: { color: fill }, objectName: name });
  if (icon && deck.icons[icon]) {
    const p = d * 0.24;
    s.addImage({ data: deck.icons[icon], x: x + p, y: y + p, w: d - 2 * p, h: d - 2 * p, objectName: name + "-icon" });
  } else {
    if (icon) warn(`아이콘 '${icon}'이(가) 로드되지 않았습니다. H.loadIcons로 먼저 불러오세요.`);
    s.addText(String(label ?? ""), txt({ x, y, w: d, h: d, fontSize: Math.round(d * 30), bold: true, color: BRAND.white, align: "center", valign: "middle" }));
  }
}

// ---------------------------------------------------------------- 덱 생성과 레이아웃
function createDeck({ title, shortTitle, author = "Hallym Investment", subject = "" }) {
  const pres = new pptxgen();
  pres.layout = "LAYOUT_16x9";
  pres.author = author;
  pres.company = "Hallym Investment";
  pres.subject = subject;
  pres.title = title;
  pres.theme = { headFontFace: FONT, bodyFontFace: FONT };
  const head = shortTitle || title;

  // 본문(밝은 배경): 상단 브랜드 표기 + 결론형 제목 + 하단 출처·쪽 번호
  pres.defineSlideMaster({
    title: "H_CONTENT",
    background: { color: BRAND.white },
    margin: [0.5, 0.5, 0.6, 0.5],
    objects: [
      { text: { text: "HALLYM INVESTMENT", options: { x: M, y: 0.2, w: 3.5, h: 0.22, fontFace: FONT, fontSize: SIZE.brand, bold: true, color: BRAND.teal, charSpacing: 2, margin: 0 } } },
      { text: { text: head, options: { x: W - M - 4.5, y: 0.2, w: 4.5, h: 0.22, fontFace: FONT, fontSize: SIZE.brand, color: BRAND.grey, align: "right", margin: 0 } } },
      { placeholder: { options: { name: "title", type: "title", x: M, y: 0.5, w: W - 2 * M, h: 0.7, fontFace: FONT, fontSize: SIZE.title, bold: true, color: BRAND.navy, align: "left", valign: "middle", margin: 0 }, text: "" } },
      { placeholder: { options: { name: "source", type: "body", x: M, y: 5.17, w: 8.2, h: 0.3, fontFace: FONT, fontSize: 9, color: BRAND.grey, valign: "middle", margin: 0 }, text: "" } },
    ],
    slideNumber: { x: W - M - 0.6, y: 5.17, w: 0.6, h: 0.3, fontFace: FONT, fontSize: 9, color: BRAND.grey, align: "right" },
  });
  // 본문(어두운 배경): 강조 메시지·시나리오 결과 등 리듬을 바꿀 때
  pres.defineSlideMaster({
    title: "H_DARK",
    background: { color: BRAND.navy },
    objects: [
      { text: { text: "HALLYM INVESTMENT", options: { x: M, y: 0.2, w: 3.5, h: 0.22, fontFace: FONT, fontSize: SIZE.brand, bold: true, color: BRAND.gold, charSpacing: 2, margin: 0 } } },
      { text: { text: head, options: { x: W - M - 4.5, y: 0.2, w: 4.5, h: 0.22, fontFace: FONT, fontSize: SIZE.brand, color: BRAND.mute, align: "right", margin: 0 } } },
      { placeholder: { options: { name: "title", type: "title", x: M, y: 0.5, w: W - 2 * M, h: 0.7, fontFace: FONT, fontSize: SIZE.title, bold: true, color: BRAND.white, align: "left", valign: "middle", margin: 0 }, text: "" } },
      { placeholder: { options: { name: "source", type: "body", x: M, y: 5.17, w: 8.2, h: 0.3, fontFace: FONT, fontSize: 9, color: BRAND.mute, valign: "middle", margin: 0 }, text: "" } },
    ],
    slideNumber: { x: W - M - 0.6, y: 5.17, w: 0.6, h: 0.3, fontFace: FONT, fontSize: 9, color: BRAND.mute, align: "right" },
  });
  // 섹션 구분
  pres.defineSlideMaster({
    title: "H_SECTION",
    background: { color: BRAND.navy },
    objects: [
      { text: { text: "HALLYM INVESTMENT", options: { x: M, y: 0.2, w: 3.5, h: 0.22, fontFace: FONT, fontSize: SIZE.brand, bold: true, color: BRAND.gold, charSpacing: 2, margin: 0 } } },
      { placeholder: { options: { name: "title", type: "title", x: 1.6, y: 2.0, w: 7.9, h: 0.9, fontFace: FONT, fontSize: SIZE.sectionTitle, bold: true, color: BRAND.white, align: "left", valign: "middle", margin: 0 }, text: "" } },
    ],
    slideNumber: { x: W - M - 0.6, y: 5.17, w: 0.6, h: 0.3, fontFace: FONT, fontSize: 9, color: BRAND.mute, align: "right" },
  });
  // 표지·Q&A (쪽 번호·출처를 두지 않는 의도된 예외: brand.md 참고)
  pres.defineSlideMaster({
    title: "H_COVER",
    background: { color: BRAND.navy },
    objects: [
      { placeholder: { options: { name: "title", type: "title", x: M, y: 1.7, w: 4.6, h: 1.2, fontFace: FONT, fontSize: SIZE.coverTitle, bold: true, color: BRAND.white, align: "left", valign: "top", margin: 0 }, text: "" } },
    ],
  });

  return { pres, title, shortTitle, count: 0, sections: {}, icons: {}, types: [] };
}

function newSlide(deck, master, section, type) {
  if (section && !deck.sections[section]) { deck.pres.addSection({ title: section }); deck.sections[section] = true; }
  deck.current = section || deck.current || "본문";
  if (!deck.sections[deck.current]) { deck.pres.addSection({ title: deck.current }); deck.sections[deck.current] = true; }
  deck.count += 1;
  deck.types.push(type);
  const t = deck.types;
  if (t.length >= 3 && t[t.length - 1] === t[t.length - 2] && t[t.length - 2] === t[t.length - 3]) warn(`'${type}' 유형이 3장 연속입니다. 유형을 섞어 리듬을 주세요.`);
  return deck.pres.addSlide({ masterName: master, sectionTitle: deck.current });
}

function contentSlide(deck, spec, type, dark = false) {
  requireSource(spec, spec.title);
  const s = newSlide(deck, dark ? "H_DARK" : "H_CONTENT", spec.section, type);
  s.addText(spec.title, { placeholder: "title" });
  s.addText(spec.source || "", { placeholder: "source" });
  if (spec.title && estimateLines(spec.title, W - 2 * M, SIZE.title) > 1) warn(`제목이 한 줄을 넘을 수 있습니다: "${spec.title}" (30자 안팎 권장)`);
  return s;
}

/** 하단 결론 박스. label 기본값은 "Hallym's View", 빈 문자열이면 머리말 없이 쓴다(가정·각주용). */
function takeaway(s, text, y, h = 0.85, label = "Hallym's View", dark = false) {
  s.addShape("roundRect", { x: M, y, w: W - 2 * M, h, rectRadius: 0.06, fill: { color: dark ? BRAND.navy2 : BRAND.tealTint }, line: { color: dark ? BRAND.navy2 : BRAND.tealTint }, objectName: "takeaway-box" });
  const runs = [];
  if (label) runs.push({ text: label + "  ", options: { bold: true, color: dark ? BRAND.gold : BRAND.teal } });
  runs.push({ text, options: { color: dark ? BRAND.white : BRAND.ink } });
  s.addText(runs, txt({ x: M + 0.25, y: y + 0.1, w: W - 2 * M - 0.5, h: h - 0.2, fontSize: SIZE.small, valign: "middle" }));
}
const view = (spec) => (spec.viewLabel === undefined ? "Hallym's View" : spec.viewLabel);

// ---------------------------------------------------------------- 슬라이드 유형
/** 표지: 우측 이미지 + 좌측 제목 */
function cover(deck, spec, notes) {
  const s = newSlide(deck, "H_COVER", spec.section || "표지", "cover");
  if (spec.image && fs.existsSync(spec.image)) {
    if (!spec.imageRatio) warn("표지 imageRatio가 없어 16:9로 가정합니다. 실제 이미지의 가로÷세로 값을 넣으세요(예: 1376/768).");
    const ratio = spec.imageRatio || 16 / 9;
    const ih = H, iw = ih * ratio;
    s.addImage({ path: spec.image, x: W - iw * 0.62, y: 0, w: iw, h: ih, objectName: "cover-image" });
    s.addShape("rect", { x: 0, y: 0, w: 4.0, h: H, fill: { color: BRAND.navy }, line: { color: BRAND.navy }, objectName: "cover-panel" });
    s.addShape("rect", { x: 4.0, y: 0, w: 1.2, h: H, fill: { color: BRAND.navy, transparency: 35 }, line: { color: BRAND.navy, transparency: 100 }, objectName: "cover-fade" });
  }
  s.addText("HALLYM INVESTMENT", txt({ x: M, y: 0.45, w: 4, h: 0.3, fontSize: 11, bold: true, color: BRAND.gold, charSpacing: 3 }));
  if (spec.kicker) s.addText(spec.kicker, txt({ x: M, y: 1.25, w: 4.6, h: 0.35, fontSize: 13, color: "9FD6DA" }));
  s.addText(spec.title, { placeholder: "title" });
  if (spec.subtitle) s.addText(spec.subtitle, txt({ x: M, y: 3.0, w: 3.6, h: 0.9, fontSize: 13, color: "D1D5DB" }));
  if (spec.meta) s.addText(spec.meta.join("\n"), txt({ x: M, y: 4.25, w: 3.6, h: 0.9, fontSize: 10, color: BRAND.mute, valign: "bottom" }));
  requireNotes(s, notes, "표지");
  return s;
}

/** 섹션 구분: 큰 금색 번호 + 섹션 제목 */
function section(deck, spec, notes) {
  const s = newSlide(deck, "H_SECTION", spec.section || spec.title, "section");
  s.addText(String(spec.no).padStart(2, "0"), txt({ x: M, y: 1.85, w: 1.0, h: 1.2, fontSize: 54, bold: true, color: BRAND.gold, valign: "middle" }));
  s.addText(spec.title, { placeholder: "title" });
  if (spec.sub) s.addText(spec.sub, txt({ x: 1.6, y: 2.95, w: 7.9, h: 0.6, fontSize: 14, color: BRAND.soft }));
  requireNotes(s, notes, "섹션 " + spec.title);
  return s;
}

/** 핵심 수치(KPI) 카드 2~4개 + 하단 결론. kpis[i].icon으로 아이콘 추가 가능. spec.dark로 어두운 배경 */
function kpi(deck, spec, notes) {
  checkItems(spec.kpis, spec.title, "KPI 카드");
  const dark = !!spec.dark;
  const s = contentSlide(deck, spec, "kpi", dark);
  const n = spec.kpis.length, gap = 0.3, w = (W - 2 * M - gap * (n - 1)) / n, y = CONTENT_TOP + 0.1;
  const h = spec.takeaway ? 2.35 : CONTENT_BOTTOM - y;
  spec.kpis.forEach((k, i) => {
    const x = M + i * (w + gap), fill = dark ? BRAND.navy2 : (k.tint || BRAND.tint);
    s.addShape("roundRect", { x, y, w, h, rectRadius: 0.08, fill: { color: fill }, line: { color: fill }, objectName: `kpi-card-${i + 1}` });
    let lx = x + 0.22;
    if (k.icon) { iconCircle(deck, s, { x: x + 0.22, y: y + 0.2, d: 0.42, fill: k.color || BRAND.teal, icon: k.icon, name: `kpi-icon-${i + 1}` }); lx = x + 0.75; }
    s.addText(k.label, txt({ x: lx, y: y + 0.2, w: x + w - 0.22 - lx, h: 0.42, fontSize: 12, bold: true, color: dark ? BRAND.soft : (k.color || BRAND.navy), valign: "middle" }));
    s.addText(k.value, txt({ x: x + 0.22, y: y + 0.72, w: w - 0.44, h: 0.95, fontSize: k.valueSize || SIZE.kpi, bold: true, color: k.valueColor || BRAND.gold, valign: "middle", fit: "shrink" }));
    if (k.sub) s.addText(k.sub, txt({ x: x + 0.22, y: y + 1.7, w: w - 0.44, h: h - 1.8, fontSize: 11, color: dark ? BRAND.mute : BRAND.grey }));
  });
  if (spec.takeaway) takeaway(s, spec.takeaway, y + h + 0.3, 0.85, view(spec), dark);
  requireNotes(s, notes, spec.title);
  return s;
}

/** 강조 메시지(어두운 배경): 큰 금색 숫자·문구 하나 + 근거 2~3개. 덱의 리듬을 바꿀 때 1~2장 사용 */
function statement(deck, spec, notes) {
  checkItems(spec.points, spec.title, "근거");
  const s = contentSlide(deck, spec, "statement", true);
  s.addText(spec.big, txt({ x: M, y: 1.45, w: 4.3, h: 1.35, fontSize: spec.bigSize || fitSize(spec.big, 4.3, 54), bold: true, color: BRAND.gold, valign: "middle", fit: "shrink" }));
  if (spec.bigLabel) s.addText(spec.bigLabel, txt({ x: M, y: 2.85, w: 4.3, h: 0.9, fontSize: 14, color: BRAND.soft }));
  if (spec.points) {
    const x = 5.2, w = W - M - x, each = Math.min(1.15, (CONTENT_BOTTOM - 1.45) / spec.points.length);
    spec.points.forEach((p, i) => {
      const y = 1.45 + i * each;
      iconCircle(deck, s, { x, y, d: 0.45, fill: BRAND.teal, icon: p.icon, label: i + 1, name: `statement-dot-${i + 1}` });
      s.addText([{ text: p.head + "\n", options: { bold: true, color: BRAND.white, fontSize: 13 } }, { text: p.body || "", options: { color: BRAND.soft, fontSize: 11 } }],
        txt({ x: x + 0.6, y: y - 0.02, w: w - 0.6, h: each - 0.1 }));
    });
  }
  if (spec.takeaway) takeaway(s, spec.takeaway, 4.1, 0.8, view(spec), true);
  requireNotes(s, notes, spec.title);
  return s;
}

/** 네이티브 차트 + 오른쪽 인사이트 2~3개 */
function chart(deck, spec, notes) {
  checkItems(spec.insights, spec.title, "인사이트");
  const s = contentSlide(deck, spec, "chart");
  const c = spec.chart;
  const type = { bar: deck.pres.charts.BAR, line: deck.pres.charts.LINE }[c.type || "bar"];
  const data = c.series.map((sr) => ({ name: sr.name, labels: c.categories, values: sr.values }));
  const chartW = spec.insights ? 5.9 : W - 2 * M;
  const chartH = (spec.takeaway ? CONTENT_BOTTOM - 0.85 : CONTENT_BOTTOM) - CONTENT_TOP;
  const stacked = c.grouping === "stacked";
  const opts = {
    x: M, y: CONTENT_TOP, w: chartW, h: chartH,
    barDir: c.barDir || "col", barGrouping: c.grouping || "clustered", barGapWidthPct: 60,
    chartColors: c.series.map((sr) => sr.color || BRAND.navy),
    showTitle: !!c.title, title: c.title || "", titleFontFace: "+mn-lt", titleFontSize: 11, titleColor: BRAND.ink,
    showValue: c.showValue !== false, dataLabelPosition: stacked ? "ctr" : (c.type === "line" ? "t" : "outEnd"),
    dataLabelFontFace: "+mn-lt", dataLabelFontSize: 9, dataLabelColor: stacked ? BRAND.white : BRAND.ink,
    dataLabelFormatCode: c.format || "0.0",
    catAxisLabelFontFace: "+mn-lt", catAxisLabelFontSize: 10, catAxisLabelColor: BRAND.grey,
    valAxisLabelFontFace: "+mn-lt", valAxisLabelFontSize: 9, valAxisLabelColor: BRAND.grey, valAxisLabelFormatCode: c.axisFormat || "0",
    valGridLine: { color: BRAND.line, size: 0.5 }, catGridLine: { style: "none" },
    showLegend: c.series.length > 1, legendPos: "t", legendFontFace: "+mn-lt", legendFontSize: 10, legendColor: BRAND.ink,
    showValAxisTitle: !!c.unit, valAxisTitle: c.unit || "", valAxisTitleFontFace: "+mn-lt", valAxisTitleFontSize: 9, valAxisTitleColor: BRAND.grey,
    lineSize: 2.25, lineDataSymbolSize: 7,
    objectName: "chart-main",
  };
  if (c.barDir === "bar") opts.catAxisOrientation = "maxMin"; // 가로 막대는 첫 항목이 위에 오도록
  if (c.valMax !== undefined) opts.valAxisMaxVal = c.valMax;
  if (c.valMin !== undefined) opts.valAxisMinVal = c.valMin;
  s.addChart(type, data, opts);
  if (spec.insights) bulletsPanel(deck, s, spec.insights, M + chartW + 0.3, CONTENT_TOP, W - M - (M + chartW + 0.3), chartH, spec.insightTitle);
  if (spec.takeaway) takeaway(s, spec.takeaway, CONTENT_BOTTOM - 0.7, 0.7, view(spec));
  requireNotes(s, notes, spec.title);
  return s;
}

/** 인사이트 패널: 아이콘(또는 번호) 원 + 굵은 머리말 + 설명 */
function bulletsPanel(deck, s, items, x, y, w, h, head, dark = false) {
  let cy = y;
  if (head) { s.addText(head, txt({ x, y: cy, w, h: 0.35, fontSize: 12, bold: true, color: dark ? BRAND.gold : BRAND.teal })); cy += 0.45; }
  const each = Math.min(1.25, (y + h - cy) / items.length);
  items.forEach((it, i) => {
    const o = typeof it === "string" ? { body: it } : it;
    iconCircle(deck, s, { x, y: cy + 0.02, d: 0.36, fill: o.color || BRAND.navy, icon: o.icon, label: i + 1, name: `insight-dot-${i + 1}` });
    const parts = o.head ? [{ text: o.head + "\n", options: { bold: true, color: dark ? BRAND.white : BRAND.navy, fontSize: 13 } }, { text: o.body || "", options: { color: dark ? BRAND.soft : BRAND.ink, fontSize: 12 } }]
      : [{ text: o.body, options: { color: dark ? BRAND.soft : BRAND.ink } }];
    s.addText(parts, txt({ x: x + 0.5, y: cy, w: w - 0.5, h: each - 0.1, fontSize: 12 }));
    cy += each;
  });
}

/** 큰 수치 하나(왼쪽) + 설명 카드(오른쪽). 한 숫자가 메시지 전체를 대표할 때 */
function split(deck, spec, notes) {
  checkItems(spec.points, spec.title, "근거");
  const s = contentSlide(deck, spec, "split");
  const lw = 3.6;
  s.addShape("roundRect", { x: M, y: CONTENT_TOP, w: lw, h: CONTENT_BOTTOM - CONTENT_TOP, rectRadius: 0.08, fill: { color: BRAND.navy }, line: { color: BRAND.navy }, objectName: "split-panel" });
  if (spec.bigIcon) iconCircle(deck, s, { x: M + 0.3, y: CONTENT_TOP + 0.3, d: 0.5, fill: BRAND.teal, icon: spec.bigIcon, name: "split-icon" });
  s.addText(spec.big, txt({ x: M + 0.3, y: CONTENT_TOP + 1.0, w: lw - 0.6, h: 1.0, fontSize: spec.bigSize || fitSize(spec.big, lw - 0.6, 48), bold: true, color: BRAND.gold, valign: "middle", fit: "shrink" }));
  if (spec.bigLabel) s.addText(spec.bigLabel, txt({ x: M + 0.3, y: CONTENT_TOP + 2.05, w: lw - 0.6, h: 1.4, fontSize: 13, color: BRAND.soft }));
  bulletsPanel(deck, s, spec.points, M + lw + 0.4, CONTENT_TOP + 0.05, W - M - (M + lw + 0.4), CONTENT_BOTTOM - CONTENT_TOP - 0.05, spec.pointsTitle);
  requireNotes(s, notes, spec.title);
  return s;
}

/** 비교표: header + rows. verdictCol 지정 시 해당 열을 배지처럼 색칠 */
function table(deck, spec, notes) {
  if (spec.rows.length > 7) warn(`'${spec.title}' 표가 ${spec.rows.length}행입니다. 7행 이하로 줄이거나 나누세요.`);
  const s = contentSlide(deck, spec, "table");
  const colW = spec.colW || spec.header.map(() => (W - 2 * M) / spec.header.length);
  const fs_ = spec.fontSize || 11;
  const rows = [spec.header.map((h) => ({ text: h, options: { bold: true, color: BRAND.white, fill: { color: BRAND.navy }, align: "center" } }))];
  spec.rows.forEach((r, ri) => {
    rows.push(r.map((c, ci) => {
      const o = { color: BRAND.ink, fill: { color: ri % 2 ? BRAND.tint : BRAND.white }, align: ci === 0 ? "left" : (spec.align || "center") };
      if (ci === 0) o.bold = true;
      if (spec.verdictCol === ci) {
        const tone = spec.verdictTone ? spec.verdictTone(c) : STATUS[c] || null;
        if (tone) { o.color = tone.fg; o.fill = { color: tone.bg }; o.bold = true; }
      }
      if (spec.highlight && spec.highlight(ri, ci)) { o.color = BRAND.navy; o.bold = true; }
      return { text: String(c), options: o };
    }));
  });
  s.addTable(rows, { x: M, y: CONTENT_TOP, w: W - 2 * M, colW, fontFace: FONT, fontSize: fs_, valign: "middle", margin: [0.04, 0.08, 0.04, 0.08], border: { type: "solid", pt: 0.5, color: BRAND.line }, rowH: spec.rowH || 0.4, autoPage: false, objectName: "table-main" });
  if (spec.note) takeaway(s, spec.note, CONTENT_BOTTOM - 0.7, 0.72, view(spec));
  requireNotes(s, notes, spec.title);
  return s;
}

/** 타임라인: 가로 축 위 사건 4~6개 */
function timeline(deck, spec, notes) {
  if (spec.events.length > 6) warn(`'${spec.title}' 사건이 ${spec.events.length}개입니다. 6개 이하를 권장합니다.`);
  const s = contentSlide(deck, spec, "timeline");
  const ev = spec.events, n = ev.length, x0 = M + 0.2, x1 = W - M - 0.2, axisY = 2.55;
  s.addShape("line", { x: x0, y: axisY, w: x1 - x0, h: 0, line: { color: BRAND.line, width: 2 }, objectName: "timeline-axis" });
  const step = (x1 - x0) / n;
  ev.forEach((e, i) => {
    const cx = x0 + step * (i + 0.5), col = { up: BRAND.teal, peak: BRAND.gold, down: BRAND.red, neutral: BRAND.navy }[e.tone || "neutral"];
    s.addShape("ellipse", { x: cx - 0.13, y: axisY - 0.13, w: 0.26, h: 0.26, fill: { color: col }, line: { color: BRAND.white, width: 1.5 }, objectName: `timeline-dot-${i + 1}` });
    s.addText(e.date, txt({ x: cx - step / 2 + 0.05, y: axisY - 0.95, w: step - 0.1, h: 0.4, fontSize: 12, bold: true, color: col, align: "center", valign: "bottom" }));
    if (e.value) s.addText(e.value, txt({ x: cx - step / 2 + 0.05, y: axisY - 0.55, w: step - 0.1, h: 0.32, fontSize: 11, bold: true, color: BRAND.navy, align: "center", valign: "bottom" }));
    s.addText(e.text, txt({ x: cx - step / 2 + 0.05, y: axisY + 0.3, w: step - 0.1, h: 1.05, fontSize: 11, align: "center" }));
  });
  if (spec.takeaway) takeaway(s, spec.takeaway, 4.05, 0.85, view(spec));
  requireNotes(s, notes, spec.title);
  return s;
}

/** 카드형 논점·비교 (2~4개). layout: "row"(가로 한 줄, 기본) | "grid"(2×2). 카드 높이는 내용에 맞춰 자동 조절 */
function cards(deck, spec, notes) {
  checkItems(spec.cards, spec.title, "카드");
  spec.cards.forEach((c) => checkItems(c.items, spec.title, `'${c.head}' 카드 항목`));
  const s = contentSlide(deck, spec, "cards");
  const grid = spec.layout === "grid" && spec.cards.length >= 3;
  const cols = grid ? 2 : spec.cards.length, rowsN = grid ? Math.ceil(spec.cards.length / 2) : 1;
  const gap = 0.3, w = (W - 2 * M - gap * (cols - 1)) / cols;
  const areaBottom = spec.takeaway ? CONTENT_BOTTOM - 1.05 : CONTENT_BOTTOM;
  const maxItems = Math.max(...spec.cards.map((c) => c.items.length));
  const lines = Math.max(...spec.cards.map((c) => c.items.reduce((a, t) => a + estimateLines(t, w - 0.6, 12), 0)));
  const headH = 0.95 + (spec.cards.some((c) => c.tag) ? 0.15 : 0);
  const need = headH + lines * 0.24 + maxItems * 0.06 + 0.2;
  const avail = (areaBottom - CONTENT_TOP - gap * (rowsN - 1)) / rowsN;
  const h = Math.min(avail, Math.max(grid ? 1.3 : 1.8, need));
  const y0 = CONTENT_TOP + (avail - h) * (grid ? 0 : 0.0);
  spec.cards.forEach((c, i) => {
    const col = i % cols, row = Math.floor(i / cols);
    const x = M + col * (w + gap), y = y0 + row * (h + gap);
    s.addShape("roundRect", { x, y, w, h, rectRadius: 0.08, fill: { color: c.tint || BRAND.tint }, line: { color: c.tint || BRAND.tint }, objectName: `card-${i + 1}` });
    let hy = y + 0.2, hx = x + 0.22;
    if (c.icon) { iconCircle(deck, s, { x: hx, y: hy, d: 0.5, fill: c.color || BRAND.teal, icon: c.icon, name: `card-icon-${i + 1}` }); hx += 0.65; }
    if (c.tag) s.addText(c.tag, txt({ x: hx, y: hy, w: x + w - 0.22 - hx, h: 0.22, fontSize: 10, bold: true, color: c.color || BRAND.teal, charSpacing: 1 }));
    s.addText(c.head, txt({ x: hx, y: hy + (c.tag ? 0.22 : 0), w: x + w - 0.22 - hx, h: c.tag ? 0.5 : 0.55, fontSize: 15, bold: true, color: c.color || BRAND.navy, valign: c.tag ? "top" : "middle" }));
    const items = c.items.map((t, k) => ({ text: t, options: { bullet: { indent: 12 }, breakLine: k < c.items.length - 1 } }));
    const by = y + headH;
    s.addText(items, txt({ x: x + 0.22, y: by, w: w - 0.44, h: y + h - by - 0.12, fontSize: 12, paraSpaceAfter: 4 }));
  });
  if (spec.takeaway) takeaway(s, spec.takeaway, Math.min(y0 + rowsN * h + gap * (rowsN - 1) + 0.25, CONTENT_BOTTOM - 0.85), 0.85, view(spec));
  requireNotes(s, notes, spec.title);
  return s;
}

/** 시나리오: 비관·기본·낙관 카드 (확률, 가정, 종목별 목표주가·변화율). 'Hallym 추정'이 출처에 자동 표기된다 */
function scenario(deck, spec, notes) {
  if (spec.source && !/Hallym 추정/.test(spec.source)) spec.source = spec.source + " · Hallym 추정";
  if (!spec.source) spec.source = "자료: Hallym 추정";
  const dark = !!spec.dark;
  const s = contentSlide(deck, spec, "scenario", dark);
  const sc = spec.scenarios, n = sc.length, gap = 0.25, w = (W - 2 * M - gap * (n - 1)) / n;
  const top = CONTENT_TOP, h = spec.takeaway ? 2.85 : CONTENT_BOTTOM - top;
  const toneCol = { bear: BRAND.red, base: BRAND.teal, bull: BRAND.gold, stress: BRAND.red };
  sc.forEach((o, i) => {
    const x = M + i * (w + gap), accent = toneCol[o.tone] || BRAND.teal;
    const fill = dark ? BRAND.navy2 : BRAND.tint;
    s.addShape("roundRect", { x, y: top, w, h, rectRadius: 0.08, fill: { color: fill }, line: { color: o.highlight ? BRAND.gold : fill, width: o.highlight ? 1.5 : 0.5 }, objectName: `scenario-card-${i + 1}` });
    s.addText(o.prob || "", txt({ x: x + 0.2, y: top + 0.15, w: 1.2, h: 0.55, fontSize: 24, bold: true, color: accent, valign: "middle" }));
    s.addText(o.name, txt({ x: x + 1.3, y: top + 0.15, w: w - 1.5, h: 0.55, fontSize: 14, bold: true, color: dark ? BRAND.white : BRAND.navy, valign: "middle" }));
    s.addText(o.assumption || "", txt({ x: x + 0.2, y: top + 0.75, w: w - 0.4, h: 0.75, fontSize: 10.5, color: dark ? BRAND.soft : BRAND.grey }));
    (o.values || []).forEach((v, k) => {
      const yy = top + 1.55 + k * 0.6;
      s.addText(v.label, txt({ x: x + 0.2, y: yy, w: w - 0.4, h: 0.22, fontSize: 10, bold: true, color: v.color || (dark ? BRAND.soft : BRAND.navy) }));
      s.addText([{ text: v.target + "  ", options: { bold: true, color: dark ? BRAND.white : BRAND.navy, fontSize: 14 } }, { text: v.change || "", options: { bold: true, color: /^-/.test(v.change || "") ? BRAND.red : BRAND.teal, fontSize: 12 } }],
        txt({ x: x + 0.2, y: yy + 0.22, w: w - 0.4, h: 0.32, valign: "middle" }));
    });
  });
  if (spec.takeaway) takeaway(s, spec.takeaway, top + h + 0.25, CONTENT_BOTTOM - (top + h + 0.25), view(spec), dark);
  requireNotes(s, notes, spec.title);
  return s;
}

/** 체크리스트: 신호 / 현재 상태 / 판정 배지 */
function checklist(deck, spec, notes) {
  if (spec.items.length > 6) warn(`'${spec.title}' 체크 항목이 ${spec.items.length}개입니다. 6개 이하를 권장합니다.`);
  const s = contentSlide(deck, spec, "checklist");
  const y0 = CONTENT_TOP + 0.05, ruleH = spec.rule ? 0.6 : 0, n = spec.items.length;
  const rowH = Math.min(0.48, (CONTENT_BOTTOM - y0 - (ruleH ? ruleH + 0.12 : 0)) / n - 0.08);
  spec.items.forEach((it, i) => {
    const y = y0 + i * (rowH + 0.08), st = STATUS[it.status] || STATUS["주의"];
    s.addShape("roundRect", { x: M, y, w: W - 2 * M, h: rowH, rectRadius: 0.05, fill: { color: i % 2 ? BRAND.white : BRAND.tint }, line: { color: BRAND.line, width: 0.5 }, objectName: `check-row-${i + 1}` });
    s.addText(it.signal, txt({ x: M + 0.2, y, w: 3.4, h: rowH, fontSize: 12, bold: true, color: BRAND.navy, valign: "middle" }));
    s.addText(it.now, txt({ x: M + 3.7, y, w: 3.9, h: rowH, fontSize: 11, valign: "middle" }));
    s.addShape("roundRect", { x: W - M - 1.1, y: y + 0.09, w: 0.95, h: rowH - 0.18, rectRadius: 0.12, fill: { color: st.bg }, line: { color: st.fg, width: 0.75 }, objectName: `check-badge-${i + 1}` });
    s.addText(it.status, txt({ x: W - M - 1.1, y: y + 0.09, w: 0.95, h: rowH - 0.18, fontSize: 11, bold: true, color: st.fg, align: "center", valign: "middle" }));
  });
  if (spec.rule) takeaway(s, spec.rule, y0 + n * (rowH + 0.08) + 0.04, ruleH, view(spec));
  requireNotes(s, notes, spec.title);
  return s;
}

/** 결론·투자의견: 종목 카드(세로 가운데 정렬) + 핵심 근거 */
function conclusion(deck, spec, notes) {
  checkItems(spec.points, spec.title, "근거");
  const s = contentSlide(deck, spec, "conclusion");
  const n = spec.opinions.length, gap = 0.2, w = 4.3, ch = 1.25;
  const total = n * ch + (n - 1) * gap, y = CONTENT_TOP + Math.max(0, (CONTENT_BOTTOM - CONTENT_TOP - total) / 2);
  spec.opinions.forEach((o, i) => {
    const yy = y + i * (ch + gap);
    s.addShape("roundRect", { x: M, y: yy, w, h: ch, rectRadius: 0.08, fill: { color: BRAND.tint }, line: { color: o.color || BRAND.navy, width: 1.25 }, objectName: `opinion-card-${i + 1}` });
    s.addText(o.name, txt({ x: M + 0.2, y: yy + 0.14, w: 2.2, h: 0.35, fontSize: 15, bold: true, color: o.color || BRAND.navy }));
    s.addText(o.rating, txt({ x: M + 2.3, y: yy + 0.14, w: 1.8, h: 0.35, fontSize: 12, bold: true, color: BRAND.teal, align: "right" }));
    s.addText(o.target, txt({ x: M + 0.2, y: yy + 0.55, w: 2.7, h: 0.55, fontSize: 24, bold: true, color: BRAND.gold, valign: "middle" }));
    s.addText(o.upside, txt({ x: M + 2.9, y: yy + 0.55, w: 1.2, h: 0.55, fontSize: 13, bold: true, color: BRAND.navy, align: "right", valign: "middle" }));
  });
  const px = M + w + 0.35;
  bulletsPanel(deck, s, spec.points, px, CONTENT_TOP + 0.05, W - M - px, CONTENT_BOTTOM - CONTENT_TOP - 0.05, spec.pointsTitle);
  requireNotes(s, notes, spec.title);
  return s;
}

/** Q&A 마무리 (쪽 번호·출처를 두지 않는 의도된 예외) */
function qna(deck, spec, notes) {
  checkItems(spec.questions, "Q&A", "예상 질문");
  const s = newSlide(deck, "H_COVER", spec.section || "Q&A", "qna");
  s.addText("HALLYM INVESTMENT", txt({ x: M, y: 0.45, w: 4, h: 0.3, fontSize: 11, bold: true, color: BRAND.gold, charSpacing: 3 }));
  s.addText(spec.title || "Q&A", { placeholder: "title" });
  if (spec.questions) {
    s.addText("예상 질문", txt({ x: 5.4, y: 1.3, w: 4.1, h: 0.35, fontSize: 12, bold: true, color: BRAND.gold }));
    const items = spec.questions.map((q, k) => ({ text: q, options: { bullet: { type: "number" }, breakLine: k < spec.questions.length - 1 } }));
    s.addText(items, txt({ x: 5.4, y: 1.75, w: 4.1, h: 2.6, fontSize: 12, color: "E5E7EB", paraSpaceAfter: 8 }));
  }
  if (spec.footer) s.addText(spec.footer, txt({ x: M, y: 4.6, w: 9, h: 0.6, fontSize: 9, color: BRAND.mute, valign: "bottom" }));
  requireNotes(s, notes, "Q&A");
  return s;
}

// ---------------------------------------------------------------- 저장
async function finalize(deck, fileName) {
  await deck.pres.writeFile({ fileName });
  // pptx 기본 skill의 applyTheme로 테마 색상을 덱에 기록한다(없으면 건너뜀).
  const candidates = [process.env.PPTX_SKILL_DIR, "/mnt/skills/public/pptx"].filter(Boolean).map((d) => path.join(d, "scripts/apply_theme.js"));
  const found = candidates.find((p) => fs.existsSync(p));
  if (found) await require(found).applyTheme(fileName, THEME);
  else warn("apply_theme.js를 찾지 못해 테마 색상 기록을 건너뜁니다. PPTX_SKILL_DIR 환경변수로 pptx skill 경로를 지정하세요.");
  const dark = deck.types.filter((t) => t === "statement" || t === "section").length;
  const variety = new Set(deck.types).size;
  console.log(`[hallym-deck] ${fileName} 저장 완료 (${deck.count}장, 유형 ${variety}종, 어두운 강조 ${dark}장, 아이콘 ${Object.keys(deck.icons).length}종)`);
  if (deck.count < 13 || deck.count > 17) warn(`슬라이드가 ${deck.count}장입니다. 권장 범위는 15장 내외(13~17장)입니다.`);
  if (variety < 6) warn(`슬라이드 유형이 ${variety}종뿐입니다. 6종 이상 섞으면 덱이 단조롭지 않습니다.`);
}

module.exports = {
  BRAND, FONT, SIZE, THEME, STATUS, NOTES_MIN, createDeck, loadIcons,
  cover, section, kpi, statement, chart, split, table, timeline, cards, scenario, checklist, conclusion, qna, takeaway, finalize,
};
