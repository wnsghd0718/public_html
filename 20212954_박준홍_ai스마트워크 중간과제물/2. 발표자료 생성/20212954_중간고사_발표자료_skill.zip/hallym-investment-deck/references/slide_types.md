# 슬라이드 유형별 함수 레퍼런스 (v2)

모든 함수는 `H.<함수>(deck, spec, notes)` 형태다. `notes`는 발표자 노트(1분, 200~350자)이고, 본문 슬라이드의 `spec.source`는 하단 출처 영역에 들어간다. `spec.section`을 주면 PowerPoint 구역(섹션)이 새로 시작된다.

캔버스는 16:9(10" × 5.625")이고, 본문 영역은 y 1.35"~5.0"이다.

## 목차
1. cover — 표지
2. section — 섹션 구분
3. kpi — 핵심 수치 카드
4. split — 큰 수치 하나 + 근거
5. statement — 강조 메시지 (어두운 배경)
6. chart — 네이티브 차트 + 인사이트
7. table — 비교표 (판정 배지)
8. timeline — 타임라인
9. cards — 논점·비교 카드 (가로 / 2×2)
10. scenario — 비관·기본·낙관 시나리오
11. checklist — 경보 체크리스트
12. conclusion — 투자의견 결론
13. qna — 질의응답 마무리
14. 공통 옵션 — 아이콘, 하단 박스 머리말, 어두운 배경

---

## 1. cover
```js
H.cover(deck, {
  image: "cover.png", imageRatio: 1376 / 768,      // 실제 가로÷세로 (없으면 16:9로 가정하고 경고)
  kicker: "한국 메모리 반도체 산업 투자 전망",
  title: "이번엔 다를까?",
  subtitle: "2018년 슈퍼사이클과 비교한 삼성전자·SK하이닉스 투자 전략",
  meta: ["Hallym Investment 리서치센터", "2026.10.21", "발표: 홍길동"],
}, notes);
```

## 2. section
```js
H.section(deck, { no: 1, title: "역설: 사상 최대 이익, PER 4배", sub: "왜 주가는 이익을 따라가지 못하나", section: "1. 역설" }, notes);
```
15장 덱에서는 0~2장만 쓴다. 장마다 넣으면 내용 슬라이드가 부족해진다.

## 3. kpi
```js
H.kpi(deck, {
  title: "삼성전자는 분기 영업이익 100조원 시대를 열었다",
  kpis: [
    { label: "삼성전자 3Q26 영업이익", value: "107.4조원", sub: "잠정(P), 전년 대비 +782.5%", color: H.BRAND.ss, icon: "FaMicrochip" },
    { label: "SK하이닉스 영업이익률", value: "76.3%", sub: "2Q26 확정", color: H.BRAND.sk },
    { label: "2027E PER", value: "3~4배", sub: "Hallym 추정·KB증권", color: H.BRAND.navy },
  ],
  takeaway: "역설의 원인은 이익의 '크기'가 아니라 '지속성'에 대한 의심이다.",
  source: "자료: ...",
  // dark: true  → 어두운 배경
}, notes);
```
카드 2~4개. 숫자는 8자 이내로 짧게, 설명은 `sub`로 내린다.

## 4. split
```js
H.split(deck, {
  title: "사상 최대 이익에도 주가는 2주 만에 27% 빠졌다",
  bigIcon: "FaChartLine",
  big: "-27%",
  bigLabel: "SK하이닉스 10/8 → 10/20 종가\n삼성전자는 같은 기간 -19%",
  pointsTitle: "왜 빠졌나",
  points: [ { head: "...", body: "...", icon: "FaExclamationTriangle" }, ... ],   // 2~3개
  source: "자료: ...",
}, notes);
```
숫자 하나가 메시지를 대표할 때 쓴다. 왼쪽 남색 패널에 금색 큰 숫자가 들어간다.

## 5. statement
```js
H.statement(deck, {
  title: "구조는 다르고, 습성은 같다",
  big: "다름 5 : 같음 3",
  bigLabel: "2018 vs 2026 비교 8개 항목 판정",
  points: [ { head: "다른 것", body: "AI 수요, 장기계약, HBM 공급 구조", icon: "FaLayerGroup" }, ... ],  // 2~3개
  takeaway: "'사이클이 없다'는 낙관도, '똑같다'는 비관도 과장이다.",
  source: "자료: ...",
}, notes);
```
어두운 배경 전체에 금색 큰 문구 하나. 덱에서 1~2장, 핵심 판단을 못 박을 때 쓴다.

## 6. chart
```js
H.chart(deck, {
  title: "1년 만에 영업이익이 7~9배로 불어났다",
  chart: {
    type: "bar",                 // "bar" | "line"
    categories: ["3Q25", "4Q25", "1Q26", "2Q26", "3Q26"],
    series: [
      { name: "삼성전자", values: [12.2, 20.1, 57.2, 89.5, 107.4], color: H.BRAND.ss },
      { name: "SK하이닉스", values: [11.4, 19.2, 37.6, 60.5, 77.0], color: H.BRAND.sk },
    ],
    unit: "조원", format: "0.0",
    // grouping: "stacked", barDir: "bar"(가로), valMax, valMin
  },
  insightTitle: "읽는 법",
  insights: [ { head: "가격이 이익을 끌었다", body: "...", icon: "FaCoins" }, "..." ],   // 2~3개
  takeaway: "(선택) 차트 아래 한 줄 시사점",
  source: "자료: ...",
}, notes);
```
- 네이티브 차트라 PowerPoint에서 "데이터 편집"으로 수치를 고칠 수 있다.
- 누적 가로막대(점유율): `grouping: "stacked", barDir: "bar"`. 첫 항목이 위에 오고 레이블은 막대 가운데에 놓인다.
- 음수가 있는 막대(시나리오 변화율)는 `valMin`을 음수로 준다.

## 7. table
```js
H.table(deck, {
  title: "2018년과 구조는 다르고, 주가의 습성은 같다",
  header: ["비교 항목", "2018년", "2026년", "판정"],
  colW: [1.8, 2.9, 2.9, 1.4],                  // 합계 9.0
  rows: [["수요 원천", "PC·스마트폰", "AI 데이터센터", "다름"], ...],
  verdictCol: 3,
  verdictTone: (v) => v === "다름" ? { fg: H.BRAND.teal, bg: "E6F3F4" } : { fg: H.BRAND.red, bg: "FDECEC" },
  // verdictTone을 생략하면 '경고/주의/안전' 값은 자동으로 색칠된다
  note: "(선택) 표 아래 한 줄", rowH: 0.4, fontSize: 11,
  source: "자료: ...",
}, notes);
```
행은 7개 이하. 셀 문장은 15자 안팎.

## 8. timeline
```js
H.timeline(deck, {
  title: "2018년, 주가는 이익보다 먼저 꺾였다",
  events: [
    { date: "2018.5", value: "95,300원", text: "SK하이닉스 주가 고점", tone: "peak" },
    { date: "2018.3Q", value: "이익률 57%", text: "이익 정점", tone: "up" },
    { date: "2018.10", text: "D램 고정가 하락 전환", tone: "down" },
  ],
  takeaway: "...", source: "자료: ...",
}, notes);
```
tone: `up`(청록), `peak`(금색), `down`(빨강), `neutral`(남색). 사건은 4~6개.

## 9. cards
```js
H.cards(deck, {
  title: "HBM과 장기계약, 2018년에 없던 안전장치가 생겼다",
  layout: "row",                // "row"(가로 한 줄, 기본) | "grid"(2×2, 카드 3~4개)
  cards: [
    { icon: "FaMicrochip", tag: "근거 1", head: "HBM의 웨이퍼 잠식", items: ["...", "..."], color: H.BRAND.teal },
    { icon: "FaFileContract", tag: "근거 2", head: "3~5년 장기계약", items: ["...", "..."] },
  ],
  takeaway: "...", source: "자료: ...",
}, notes);
```
카드 2~4개, 카드당 항목 2~4개. 카드 높이는 내용에 맞춰 자동으로 정해진다(빈 공간이 크게 남지 않는다). 목차는 `layout: "grid"`로 4개 질문을 2×2로 보여 주면 좋다. 기업 비교에는 카드 색을 기업 색으로 준다.

## 10. scenario
```js
H.scenario(deck, {
  title: "세 시나리오를 확률가중해 목표주가를 직접 계산했다",
  scenarios: [
    { tone: "bear", prob: "25%", name: "이익 반감", assumption: "2027 이익 컨센서스 ×0.5, PER 5배",
      values: [ { label: "SK하이닉스", target: "110만원", change: "-16%", color: H.BRAND.sk },
                { label: "삼성전자", target: "16.5만원", change: "-26%", color: H.BRAND.ss } ] },
    { tone: "base", prob: "50%", name: "기본", assumption: "...", values: [...], highlight: true },
    { tone: "bull", prob: "25%", name: "낙관", assumption: "...", values: [...] },
  ],
  takeaway: "가정: 순이익 = 영업이익 × 80%. 확률은 Hallym의 주관적 가정",
  viewLabel: "가정",            // 하단 박스가 시사점이 아니라 가정이면 머리말을 바꾼다
  source: "자료: 에프앤가이드 컨센서스",   // 'Hallym 추정'은 자동으로 붙는다
  // dark: true  → 어두운 배경
}, notes);
```
tone: `bear`(빨강), `base`(청록), `bull`(금색), `stress`(빨강, 극단 시나리오). `highlight: true`면 금색 테두리로 강조한다. 카드 3~4개.

## 11. checklist
```js
H.checklist(deck, {
  title: "경보 6개 중 '경고'는 1개, 아직 2018년이 아니다",
  items: [ { signal: "실적 호조에도 주가 하락", now: "10/8 이후 SK -27%, 삼성 -19%", status: "경고" }, ... ],
  rule: "경고가 3개 이상이 되면 비중 축소를 검토한다.",
  source: "자료: ...",
}, notes);
```
status는 `경고`·`주의`·`안전` 중 하나. 항목은 6개까지.

## 12. conclusion
```js
H.conclusion(deck, {
  title: "산업 비중확대, SK하이닉스 Top Pick",
  opinions: [
    { name: "SK하이닉스", rating: "매수 · Top Pick", target: "2,650,000원", upside: "+103%", color: H.BRAND.sk },
    { name: "삼성전자", rating: "매수", target: "400,000원", upside: "+79%", color: H.BRAND.ss },
  ],
  pointsTitle: "투자 판단의 근거",
  points: [ { head: "...", body: "...", icon: "FaBullseye" }, ... ],   // 3개
  source: "자료: Hallym 추정 ...",
}, notes);
```
종목 카드는 세로 가운데에 놓인다.

## 13. qna
```js
H.qna(deck, { title: "Q&A", questions: ["...", "...", "..."], footer: "본 자료는 ... 투자 권유가 아닙니다." }, notes);
```

## 14. 공통 옵션

**아이콘**
```js
await H.loadIcons(deck, ["FaMicrochip", "FaFileContract", "FaExclamationTriangle", "FaBullseye"]);
```
`Fa`(Font Awesome)와 `Md`(Material) 아이콘을 이름으로 쓴다. 금융 리서치에 자주 쓰는 것:

| 의미 | 아이콘 |
|---|---|
| 반도체·기술 | FaMicrochip, FaServer, FaMemory |
| 실적·성장 | FaChartLine, FaArrowUp, FaCoins |
| 계약·공급 | FaFileContract, FaHandshake, FaIndustry |
| 위험·경고 | FaExclamationTriangle, FaShieldAlt |
| 목표·판단 | FaBullseye, FaBalanceScale, FaCheckCircle |
| 비교·구조 | FaLayerGroup, FaSyncAlt, FaHistory |

아이콘이 로드되지 않았으면 원 안에 번호가 대신 들어간다.

**하단 박스 머리말** — `viewLabel`: 기본 "Hallym's View". 가정·각주면 `"가정"`이나 `""`(머리말 없음).

**어두운 배경** — `kpi`, `scenario`는 `dark: true`, `statement`는 항상 어두운 배경이다.
